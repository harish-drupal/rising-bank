


  KJE.parameters.set("INCREASE_BY_AMT",100);
  KJE.parameters.set("MORTGAGE_AMT",KJE.Default.MortgageAmt);
  KJE.parameters.set("MORTGAGE_YRS_LEFT",KJE.Default.MortgageTerm-5);
  KJE.parameters.set("MORTGAGE_YRS_LENGTH",KJE.Default.MortgageTerm);
  KJE.parameters.set("RATE",KJE.Default.RateFix30);


/**V3_CUSTOM_CODE**/
/* <!--
  Financial Calculators, &copy;1998-2017 KJE Computer Solutions, Inc.
  For more information please see:
  <A HREF="http://www.dinkytown.net">http://www.dinkytown.net</A>
 -->
 */
if (KJE.IE7and8) KJE.init();

