


  KJE.parameters.set("SIMPLE",true);



/**V3_CUSTOM_CODE**/
/* <!--
  Financial Calculators, &copy;1998-2017 KJE Computer Solutions, Inc.
  For more information please see:
  <A HREF="http://www.dinkytown.net">http://www.dinkytown.net</A>
 -->
 */
if (KJE.IE7and8) KJE.init();

