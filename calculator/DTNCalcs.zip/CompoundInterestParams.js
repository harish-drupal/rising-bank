


  KJE.parameters.set("AMOUNT",10000);
  KJE.parameters.set("INTEREST_RATE",KJE.Default.RORSave);
  KJE.parameters.set("YEARS",10);



/**V3_CUSTOM_CODE**/
/* <!--
  Financial Calculators, &copy;1998-2017 KJE Computer Solutions, Inc.
  For more information please see:
  <A HREF="http://www.dinkytown.net">http://www.dinkytown.net</A>
 -->
 */
if (KJE.IE7and8) KJE.init();

