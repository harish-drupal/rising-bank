


  KJE.parameters.set("AGE_DESIRED",65);
  KJE.parameters.set("AMT_CURRENT",10000);
  KJE.parameters.set("AMT_SAVE_MONTH",500);
  KJE.parameters.set("AGE_CURRENT",30);
  KJE.parameters.set("INFLATION_RATE",KJE.Default.InflationRate);
  KJE.parameters.set("ROR_INVEST",KJE.Default.RORMarket);


/**V3_CUSTOM_CODE**/
/* <!--
  Financial Calculators, &copy;1998-2017 KJE Computer Solutions, Inc.
  For more information please see:
  <A HREF="http://www.dinkytown.net">http://www.dinkytown.net</A>
 -->
 */
if (KJE.IE7and8) KJE.init();

